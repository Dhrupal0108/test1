let shop = document.getElementById("shop");
let shopItemsData = [{
    id: "12548",
    name: "Cookies",
    price: 120,
    desc: "okay",
    img: "img1.jpg"
},
{
    id: "12549",
    name: "Tea",
    price: 200,
    desc: "okay",
    img: "img2.jpg"
},
{
    id: "12544",
    name: "Coffee",
    price: 250,
    desc: "okay",
    img: "img3.jpg"
},
{
    id: "12542",
    name: "Soda",
    price: 40,
    desc: "okay",
    img: "img4.jpg"
}];
let basket=[];
let generateShop = () => {
    return (shop.innerHTML = shopItemsData
        .map((x) => {
            let { id, name, price, desc, img } = x;
          //  let search = basket.find((x) => x.id === id) || [];
            return `
    <div id=product-id-${id} class="item">
        <img width="220" src=${img} alt="">
        <div class="details">
          <h3>${name}</h3>
          <p>${desc}</p>
          <div class="price-quantity">
            <h2>RS. ${price} </h2>
            <div class="buttons">
              <i onclick="decrement(${id})" class="bi bi-dash-lg"></i>
              <div id=${id} class="quantity">0</div>
              <i onclick="increment(${id})" class="bi bi-plus-lg"></i>
            </div>
          </div>
        </div>
      </div>
    `;
        })
        .join(""));
};

generateShop();

let increment = (id) => {
    let selectedItem = id;
    let search = basket.find((x) => x.id === selectedItem.id);

    if (search === undefined) {
        basket.push({
            id: selectedItem.id,
            item: 1,
        });
    } else {
        search.item += 1;
    }

    // console.log(basket);
    update(selectedItem.id);
   // localStorage.setItem("data", JSON.stringify(basket));
};
let decrement = (id) => {
    let selectedItem = id;
    let search = basket.find((x) => x.id === selectedItem.id);

    if (search === undefined) return;
    else if (search.item === 0) return;
    else {
        search.item -= 1;
    }
    update(selectedItem.id);
  //  basket = basket.filter((x) => x.item !== 0);
    // console.log(basket);
    //localStorage.setItem("data", JSON.stringify(basket));
};
let update = (id) => {
    let search = basket.find((x) => x.id === id);
     console.log(search.item);
     console.log(id);
    //document.getElementById("id").innerHTML = search.item;
    //calculation();
};

// let calculation = () => {
//     let cartIcon = document.getElementById("cartAmount");
//     cartIcon.innerHTML = basket.map((x) => x.item).reduce((x, y) => x + y, 0);
// };

// calculation();