USE GroceryShop;


create table catagory(
	catagoryID int not null primary key identity(1,1),
	catagoryName varchar(48) not null,
	catagoryStatus tinyint not null,
	catagoryDate date not null,
	updateDate date not null,
	isActive tinyint not null,
);
		

alter table catagory
add constraint catagoryName_un unique(catagoryName)


USE GroceryShop;
create table product(
	productId int not null primary key identity(1,1),
	catagoryID int,
	productName varchar(48) not null,
	productPrice double not null,
	productWeight double not null,
	productQuantity int not null,
	productStatus tinyint not null,
	createdDate date not null,
	updatedDate date not null,
	isActive tinyint not null,
	productSku varchar(48) not null
);