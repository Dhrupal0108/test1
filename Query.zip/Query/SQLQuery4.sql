










	

	create database Student;

use Student;

create table student(
id int not null primary key identity,
firstName varchar(24) not null,
lastName varchar(24) not null,
Address varchar(48) not null,
mobile varchar(16) not null,
DOB date not null
);

use Student;

create table Sem1(
	id int foreign key references student(id),
	mark1 int not null,
	mark2 int not null,
	mark3 int not null
);

use Student;
create table Sem2(
 id int foreign key references student(id),
 mark1 int not null,
 mark2 int not null,
 mark3 int not null
);