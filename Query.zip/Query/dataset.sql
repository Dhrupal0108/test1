create database dataset;

use dataset;

create table product(
	prod_Id int primary key identity(1,100) not null,
	prod_Name varchar(48) not null,
	prod_Desc varchar(64) not null,
	catagory_Id int not null,
	prod_Price int not null,
	prod_Weight float not null,
	quantityPerUnit int not null,
	prod_Sku varchar(48) not null,
	prod_Size float not null,
	prod_Color varchar(12) not null,
	prod_Img varchar(48) not null,
	discountAvaliable varchar(12) not null, 
	prod_Cart varchar(250)
);
 

 use dataset;

 create table catagory(
	catagory_Id int primary key not null identity,
	catagory_Name varchar(48) unique  not null,
	description varchar(128) not null,
	picture varchar(128),
	active varchar(12) not null,
	catagory_Date date not null,
	catagory_update date not null
 );

 alter table productadd created_date datetime not null, updated_date datetime not null;use dataset;create table user_Table(	user_Id int primary key identity(1001,10) not null,	user_Email varchar(64) not null,	password varchar(48) not null,	firstName varchar(24) not null,	lastNmae varchar(24) not null,	phone float not null,	user_Created date not null,	user_Updated date not null);use dataset;create table user_Address(	address_Id int identity not null,	user_ID int,	house_No int not null,	street varchar(48) not null,	area varchar(48) not null,	city varchar(24) not null,	state varchar(24) not null,	country varchar(24) not null,	pincode int not null);use dataset;alter table user_Address  add primary key(address_Id)create table orders(	order_Id int primary key identity not null,	address_Id int,	amount int not null,	phone int not null,	order_Status varchar(32) not null,	order_Date date not null,	payment_Status  varchar(32) not null,	user_Id int);create table order_Address(	id int primary key identity not null,	user_Id int,	address_Id int,	address_Type varchar(16) not null);alter table user_Table add unique(user_Email)