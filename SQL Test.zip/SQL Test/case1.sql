
-- 1. Total income of Restaurant till now.

select sum(grandTotal) as TotalIncome from [order];

 --2. Customer who visited the restaurant more than twice.
SELECT firstName, COUNT(uId)
as NoofTimesVisited
FROM [order]
GROUP BY firstName
HAVING COUNT(uId) > 2;

 --3. List of all menus with its menu items.
select menu.title,item.title
from item
inner join menu_item 
on  menu_item.itemId=item.id 
inner join menu
on menu.ID=menu_item.menuId

--4. List out all the unique ids and possible indexes for this DB 
--schema.


 --5. List out total order placed by each User.
select firstName,count(*) 
from [order]
group by(firstName);

--6. Make a list of each user and the highest-priced menu item he 
--or she ordered.
select firstName,max(price) as highest_Priced_item
from [user],item
group by (firstName)


--7. Retrieve the name of a chef who prepares more recipes than any 
--other chef. 

select [name],count(chefId)as manyy
from chef,item_chef
where chef.id=item_chef.chefId
group by [name]
order by manyy desc
OFFSET 0 ROWS 
FETCH FIRST 1 ROWS ONLY ; 





--8. Retrieve the amount of subtotal for all day on 9th November 
--2021. (It does not include the total, formula: item price * 
--ordered qty).

select subTotal,createdAt from [order]
where createdAt = '2021-11-09';

--9. List out user along with the average amount spend at the 
--restaurant

select firstName,avg(grandTotal) 
from [order]
group by(firstName)


--10. List out the menu items which are preferred by the 
--customer at dinner time
select title as prefered_item
from item
inner join order_item
on order_item.itemId=item.id and datepart(hour,order_item.createdAt)>18;