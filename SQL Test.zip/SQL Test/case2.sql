--1. List out all questions with it�s answer which is having 
--maximum vote.

select title,poll_answer.pollId,max(answerId) from poll,poll_answer,poll_vote
group by answerId , title, poll_answer.pollId;

--2. List out all the categories which is having multiple poll 
--questions under it.

SELECT type FROM poll_question
where type='Multiple Choice';


--3. List out all the polls which are currently active.
SELECT active 
FROM poll_answer
where active=1;

--4. List out all the users who is not logged in since last week.
   SELECT id,firstName,lastLoginFROM [user] WHERE lastLogin  not between getdate()-7 and getdate()GROUP BY firstName,id,lastLogin


--5. List out all the users whose email provider is not google.
SELECT firstName,email FROM [user]
WHERE email not LIKE '%gmail.com';

--6. List out all the polls which are published in 2021.
SELECT title,publishedAt FROM poll
WHERE publishedAt LIKE '%2021%';

--7. List out all the users who did not answer any poll yet.
SELECT firstName, pollId, questionId
	FROM   [user],poll_answer
	INNER JOIN poll 
	ON     poll.id = poll_answer.pollId
	WHERE  poll_answer.pollID!= poll.id;


--8. Create all the possible unique key and indexes for this 
--database schema
CREATE UNIQUE INDEX uid
ON [user];